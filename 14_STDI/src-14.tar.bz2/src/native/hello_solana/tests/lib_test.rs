use litesvm::LiteSVM;
use solana_sdk::{
    signature::{read_keypair_file, Signer},
};

#[test]
fn test_hello_solana() {

    // Initialize the test environment
    let mut svm = LiteSVM::new();

    let solana_keypair_path = "/home/bpdp/kerjaan/utdi/kuliah/genap-2025-2026/sistem-terdistribusi-terdesentralisasi/13/src/native/hello_solana/target/deploy/hello_solana-keypair.json";
    let solana_so_path = "/home/bpdp/kerjaan/utdi/kuliah/genap-2025-2026/sistem-terdistribusi-terdesentralisasi/13/src/native/hello_solana/target/deploy/hello_solana.so";

    // Deploy your program to the test environment
    // Read keypair for correct program ID
    let program_keypair = read_keypair_file(solana_keypair_path).unwrap();
    let program_id = program_keypair.pubkey();
    //let program_bytes = include_bytes!(solana_so_path);
    svm.add_program_from_file(program_id, solana_so_path)
        .expect("Failed to deploy program");

    // Always verify
    assert!(svm.get_account(&program_id).unwrap().executable);

}

